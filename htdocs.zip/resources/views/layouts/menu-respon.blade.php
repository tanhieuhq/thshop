<div id="menu-respon">
    <a href="?page=home" title="" class="logo">THSHOP</a>
    <div id="menu-respon-wp">
        @if (session('render_menu'))
            {!! session('render_menu') !!}
        @endif
    </div>
</div>