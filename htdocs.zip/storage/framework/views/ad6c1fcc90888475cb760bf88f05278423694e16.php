
<?php $__env->startSection('content'); ?>
<?php
    if(isset($_SESSION['visits'])){
        unset($_SESSION['visits']);
    }
?>
<div id="main-content-wp" class="home-page clearfix">
    <div class="wp-inner">
        <div class="main-content fl-right">
            <div class="section" id="list-product-wp">
                <div class="section-head">
                    <h3 class="section-title"><?php echo e($cat_name); ?></h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $images = json_decode($item->image);
                                $image = $images[0];
                            ?>
                            <li>
                                <a href="<?php echo e(route('product.detail', ['slug'=>$item->slug])); ?>" title="" class="thumb">
                                    <img src="<?php echo e(url($image)); ?>">
                                </a>
                                <a href="<?php echo e(route('product.detail', ['slug'=>$item->slug])); ?>" title=""
                                    class="product-name"><?php echo Str::of($item->name)->limit(40); ?></a>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($item->price) . 'đ'); ?></span>
                                    
                                </div>
                                <div class="action clearfix">
                                    <a href="<?php echo e(route('cart.add', $item->slug)); ?>" title="Thêm giỏ hàng"
                                        class="add-cart fl-left">Thêm
                                        giỏ hàng</a>
                                    <a href="<?php echo e(route('buy.now', $item->slug)); ?>" title="Mua ngay" class="buy-now fl-right">Mua
                                        ngay</a>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanhieuunitopcv/public_html/resources/views/client/product/productList.blade.php ENDPATH**/ ?>