
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold">
            Thêm bài viết
        </div>
        <div class="card-body">
            <?php echo Form::open(['url'=>'admin/post/store','method'=>'POST','files'=>true]); ?>

                <div class="form-group">
                    <?php echo Form::label('title', 'Tiêu đề'); ?>

                    <?php echo Form::text('title', '', ['class'=>'form-control','id'=>'title']); ?>

                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('description', 'Mô tả'); ?>

                    <?php echo Form::textarea('description', '', ['class'=>'form-control','id'=>'description']); ?>

                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('content', 'Nội dung'); ?>

                    <?php echo Form::textarea('content', '', ['class'=>'form-control','id'=>'content']); ?>

                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('thumbnail', 'Chọn ảnh đại diện'); ?>

                    <?php echo Form::file('file', ['class'=>'form-control-file','id'=>'thumbnail']); ?>

                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('postcat', 'Danh mục'); ?>

                    <?php echo Form::select('postcat', [''=>'Chọn danh mục','Tin tức'=>'Tin tức','Khuyến mãi'=>'Khuyến mãi'], '', ['class'=>'form-control','id'=>'postcat']); ?>

                    <?php $__errorArgs = ['postcat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('', 'Trạng thái'); ?>

                    <div class="form-check">
                        <?php echo Form::radio('status', 'Chờ duyệt', 'checked', ['class'=>'form-check-input','id'=>'pending']); ?>

                        <?php echo Form::label('pending', 'Chờ duyệt', ['class'=>'form-check-label']); ?>

                    </div>
                    <div class="form-check">
                        <?php echo Form::radio('status', 'Công khai', '', ['class'=>'form-check-input','id'=>'public']); ?>

                        <?php echo Form::label('public', 'Công khai', ['class'=>'form-check-label']); ?>

                    </div>
                </div>
                <button type="submit" class="btn btn-primary" value="sm-add-post" name="sm-add-post">Thêm mới</button>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanhieuunitopcv/public_html/resources/views/admin/post/add.blade.php ENDPATH**/ ?>