<div class="sidebar fl-left">
    <div class="section" id="category-product-wp">
        <div class="section-head">
            <h3 class="section-title">Danh mục sản phẩm</h3>
        </div>
        <div class="secion-detail">
            <?php if(session('data_tree')): ?>
                <?php echo session('data_tree'); ?>

            <?php endif; ?>
        </div>
    </div>
    <div class="section" id="selling-wp">
        <div class="section-head">
            <h3 class="section-title">Sản phẩm bán chạy</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item">
                <?php $__currentLoopData = session('hot_products'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $images = json_decode($item->image);
                        $image = $images[0];
                    ?>
                    <li class="clearfix">
                        <a href="<?php echo e(route('product.detail', ['slug'=>$item->slug])); ?>" title=""
                            class="thumb fl-left">
                            <img src="<?php echo e($image); ?>" alt="">
                        </a>
                        <div class="info fl-right">
                            <a href="<?php echo e(route('product.detail', ['slug'=>$item->slug])); ?>" title=""
                                class="product-name"><?php echo e($item->name); ?></a>
                            <div class="price">
                                <span
                                    class="new"><?php echo e(number_format($item->price, 0, '.', ',') . 'đ'); ?></span>
                                
                            </div>
                            <a href="<?php echo e(route('buy.now', $item->slug)); ?>" title=""
                                class="buy-now">Mua ngay</a>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="section" id="banner-wp">
        <div class="section-detail">
            <a href="" title="" class="thumb">
                <img src="public/images/banner.png" alt="">
            </a>
        </div>
    </div>
</div><?php /**PATH /home/tanhieuunitopcv/public_html/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>