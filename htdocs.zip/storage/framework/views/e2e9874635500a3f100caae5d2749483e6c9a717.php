<div id="menu-respon">
    <a href="?page=home" title="" class="logo">THSHOP</a>
    <div id="menu-respon-wp">
        <?php if(session('render_menu')): ?>
            <?php echo session('render_menu'); ?>

        <?php endif; ?>
    </div>
</div><?php /**PATH /home/tanhieuunitopcv/public_html/resources/views/layouts/menu-respon.blade.php ENDPATH**/ ?>