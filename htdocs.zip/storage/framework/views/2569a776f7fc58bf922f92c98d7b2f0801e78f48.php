
<?php $__env->startSection('content'); ?>
<?php
    if(isset($_SESSION['visits'])){
        unset($_SESSION['visits']);
    }
?>
    <div id="main-content-wp" class="home-page clearfix">
        <div class="wp-inner">
            <div class="main-content fl-right">
                <div class="secion" id="breadcrumb-wp">
                    <div class="secion-detail">
                        <ul class="list-item clearfix">
                            <li>
                                <a href="" title="">Trang chủ</a>
                            </li>
                            <li>
                                <a href="" title="">Điện thoại</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="section" id="detail-product-wp">
                    <div class="section-detail clearfix">
                        <div class="thumb-wp fl-left">
                            <?php
                                $images = str_replace('\\', '/', json_decode($product->image));
                            ?>
                            <a href="" title="" id="main-thumb">
                                <img id="zoom" src="<?php echo e($images[0]); ?>"
                                    data-zoom-image="public/uploads/products/dien-thoai-iphone-14-pro-256gb-den-1.jpg" />
                            </a>
                            <div id="list-thumb">
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="" data-image="<?php echo e($item); ?>"
                                        data-zoom-image="<?php echo e($item); ?>">
                                        <img id="zoom" src="<?php echo e($item); ?>" />
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="thumb-respon-wp fl-left">
                            <img src="<?php echo e($images[0]); ?>" alt="">
                        </div>
                        <div class="info fl-right">
                            <h3 class="product-name"><?php echo e($product->name); ?></h3>
                            <div class="desc">
                                <?php echo $product->description; ?>

                            </div>
                            <p class="price"><?php echo e(number_format($product->price, 0, '.', ',') . 'đ'); ?></p>
                            <form action="<?php echo e(route('cart.add', $product->slug)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div id="num-order-wp">
                                    <a title="" id="minus"><i class="fa fa-minus"></i></a>
                                    <input type="text" name="num-order" value="1" id="num-order">
                                    <a title="" id="plus"><i class="fa fa-plus"></i></a>
                                </div>
                                
                                <input class="add-cart" type="submit" name="add-cart" value="Thêm giỏ hàng" />
                            </form>
                        </div>
                    </div>
                </div>
                <div class="section" id="post-product-wp">
                    <div class="section-head">
                        <h3 class="section-title">Mô tả sản phẩm</h3>
                    </div>
                    <div class="section-detail">
                        <?php echo $product->detail_info; ?>

                    </div>
                </div>
                <div class="section" id="same-category-wp">
                    <div class="section-head">
                        <h3 class="section-title">Cùng chuyên mục</h3>
                    </div>
                    <div class="section-detail">
                        <ul class="list-item">
                            <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $images = json_decode($item->image);
                                    $image = $images[0];
                                ?>
                                <li>
                                    <a href="<?php echo e(route('product.detail', $item->slug)); ?>" title="" class="thumb">
                                        <img src="<?php echo e($image); ?>">
                                    </a>
                                    <a href="<?php echo e(route('product.detail', $item->slug)); ?>" title=""
                                        class="product-name"><?php echo Str::of($item->name)->limit(40); ?></a>
                                    <div class="price">
                                        <span class="new"><?php echo e(number_format($item->price) . 'đ'); ?></span>
                                        
                                    </div>
                                    <div class="action clearfix">
                                        <a href="<?php echo e(route('cart.add', $item->slug)); ?>" title=""
                                            class="add-cart fl-left">Thêm
                                            giỏ hàng</a>
                                        <a href="<?php echo e(route('buy.now', $item->slug)); ?>" title=""
                                            class="buy-now fl-right">Mua
                                            ngay</a>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanhieuunitopcv/public_html/resources/views/client/product/detail.blade.php ENDPATH**/ ?>