
<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="home-page clearfix">
        <div class="wp-inner">
            <div id="main-content-wp" class="cart-page">
                <div class="section" id="breadcrumb-wp">
                    <div class="wp-inner">
                        <div class="section-detail">
                            <ul class="list-item clearfix">
                                <li>
                                    <a href="?page=home" title="">Trang chủ</a>
                                </li>
                                <li>
                                    <a href="" title="">Sản phẩm làm đẹp da</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div id="wrapper" class="wp-inner clearfix">
                    <?php if(Cart::count() > 0): ?>
                        <form action="cart/update" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="section" id="info-cart-wp">
                                <div class="section-detail table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <td>Mã sản phẩm</td>
                                                <td>Ảnh sản phẩm</td>
                                                <td>Tên sản phẩm</td>
                                                <td>Giá sản phẩm</td>
                                                <td>Số lượng</td>
                                                <td colspan="2">Thành tiền</td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td id="code" data-id="<?php echo e($item->id); ?>"><?php echo e($item->id); ?>

                                                    </td>
                                                    <td>
                                                        <a href="" title="" class="thumb">
                                                            <img src="<?php echo e($item->options->image); ?>" alt="">
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('product.detail', $item->model->slug)); ?>" title=""
                                                            class="name-product"><?php echo e($item->name); ?></a>
                                                    </td>
                                                    <td><?php echo e(number_format($item->price, 0, ',', '.')); ?>đ</td>
                                                    <td>
                                                        <input id="num-order-cart" class="num-order"
                                                            data-id="<?php echo e($item->rowId); ?>" type="number"
                                                            name="quantity_order[<?php echo e($item->rowId); ?>]" min="1"
                                                            max="20" value="<?php echo e($item->qty); ?>">
                                                    </td>
                                                    <td id="amount-<?php echo e($item->rowId); ?>">
                                                        <?php echo e(number_format($item->total, 0, ',', '.')); ?>đ</td>
                                                    <td>
                                                        <a href="<?php echo e(route('cart.remove', $item->rowId)); ?>" title=""
                                                            class="del-product"><i class="fa fa-trash-o"></i></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="7">
                                                    <div class="clearfix">
                                                        <p id="total-price" class="fl-right">Tổng giá:
                                                            <span><?php echo e(Cart::total()); ?>đ</span>
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="7">
                                                    <div class="clearfix">
                                                        <div class="fl-right">
                                                            
                                                            <a href="cart/checkout" title="" id="checkout-cart">Tiếp
                                                                tục</a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                            
                            <div class="section" id="action-cart-wp">
                                <div class="section-detail">
                                    <p class="title">Click vào <span>“Cập nhật giỏ hàng”</span> để cập nhật số lượng. Nhấn
                                        vào thanh
                                        toán để hoàn tất mua hàng.
                                    </p>

                                    <a href="?page=home" title="" id="buy-more">Mua tiếp</a><br />
                                    <a href="cart/destroy" title="" id="delete-cart">Xóa giỏ hàng</a>
                                </div>
                            </div>
                        </form>
                    <?php else: ?>
                        Giỏ hàng chưa có sản phẩm
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanhieuunitopcv/public_html/resources/views/client/cart/cart.blade.php ENDPATH**/ ?>