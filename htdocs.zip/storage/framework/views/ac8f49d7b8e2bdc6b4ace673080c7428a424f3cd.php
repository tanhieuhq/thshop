
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold">
                Thêm trang
            </div>
            <div class="card-body">
                <?php echo Form::open(['url' => route('page.update',$page->id), 'method' => 'POST']); ?>

                <div class="form-group">
                    <?php echo Form::label('title', 'Tiêu đề'); ?>

                    <?php echo Form::text('title', $page->title, ['class' => 'form-control']); ?>

                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('content', 'Nội dung'); ?>

                    <?php echo Form::textarea('content', $page->content, ['class' => 'form-control', 'id' => 'content']); ?>

                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('status', 'Trạng thái'); ?>

                    <div class="form-check">
                        <?php echo Form::radio('status', 'Đợi duyệt', $page->status == 'Đợi duyệt'? 'checked':'', ['class' => 'form-check-input', 'id' => 'pending']); ?>

                        <?php echo Form::label('pending', 'Đợi duyệt'); ?>

                    </div>
                    <div class="form-check">
                        <?php echo Form::radio('status', 'Công khai', $page->status == 'Công khai'? 'checked':'', ['class' => 'form-check-input', 'id' => 'public']); ?>

                        <?php echo Form::label('public', 'Công khai'); ?>

                    </div>
                </div>
                <div class="form-group">
                    <?php echo Form::submit('Cập nhật', ['class' => 'btn btn-primary', 'name' => 'sm-update']); ?>

                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanhieuunitopcv/public_html/resources/views/admin/page/edit.blade.php ENDPATH**/ ?>