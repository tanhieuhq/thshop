
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-5">
        <div class="row">
            <div class="col">
                <a href="?status=success">
                    <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                        <div class="card-header">ĐƠN HÀNG THÀNH CÔNG</div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($order[0]); ?></h5>
                            <p class="card-text">Đơn hàng giao dịch thành công</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col">
                <a href="?status=pending">
                    <div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
                        <div class="card-header">ĐANG XỬ LÝ</div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($order[1]); ?></h5>
                            <p class="card-text">Số lượng đơn hàng đang xử lý</p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="?status=canceled">
                    <div class="card text-white bg-dark mb-3" style="max-width: 18rem;">
                        <div class="card-header">ĐƠN HÀNG HỦY</div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($order[2]); ?></h5>
                            <p class="card-text">Số đơn bị hủy trong hệ thống</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col">
                <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
                    <div class="card-header">DOANH SỐ</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(number_format($order[4], 0, ',', '.') . 'đ'); ?></h5>
                        <p class="card-text">Doanh số hệ thống</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- end analytic  -->
        <div class="card">
            <div class="card-header font-weight-bold">
                ĐƠN HÀNG MỚI
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">STT</th>
                            <th scope="col">Mã</th>
                            <th scope="col">Khách hàng</th>
                            <th scope="col">Địa chỉ</th>
                            <th scope="col">Số lượng</th>
                            <th scope="col">Giá trị</th>
                            <th scope="col">Trạng thái</th>
                            <th scope="col">Thời gian</th>
                            <th scope="col">Chi tiết</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $t = 1;
                        ?>
                        <?php $__currentLoopData = $order[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox">
                                </td>
                                <td><?php echo e($t++); ?></td>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->fullname); ?></td>
                                <td><?php echo e($item->address); ?></td>
                                <td><?php echo e($item->quantity_total); ?></td>
                                <td><?php echo e(number_format($item->amount_total, 0, ',', '.') . 'đ'); ?></td>
                                <td><span
                                        class="badge <?php if($item->status == 'Thành công'): ?> badge-success <?php else: ?> badge-warning <?php endif; ?>"><?php echo e($item->status); ?></span>
                                </td>
                                <td><?php echo e($item->created_at); ?></td>
                                <td><a href="<?php echo e(route('detail.order', $item->id)); ?>" title="" class="tbody-text">Chi
                                        tiết</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($order[3]->links()); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanhieuunitopcv/public_html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>